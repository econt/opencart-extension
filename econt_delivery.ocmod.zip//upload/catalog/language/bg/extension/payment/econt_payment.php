<?php
// Text
$_['text_title'] = 'Pay With Econt';