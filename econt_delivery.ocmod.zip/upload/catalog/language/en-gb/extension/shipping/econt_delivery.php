<?php

$_['text_delivery_method_title'] = 'Econt Delivery';
$_['text_delivery_method_description'] = 'Econt Delivery';
$_['text_delivery_method_description_cd'] = 'cash on delivery';
$_['text_catalog_controller_api_extension_econt_delivery_permission_error'] = 'Access Denied!';
$_['text_catalog_controller_api_extension_econt_delivery_shop_id_error'] = 'Error. Invalid security code!';
$_['text_econt_delivery_order'] = 'Order';
$_['text_econt_delivery_order_discount'] = 'Discount';
$_['text_cod_label'] = 'cash on delivery)';
$_['text_delivery_method_calculate_button'] = 'Calculate shipping';
$_['text_delivery_method_change_button'] = 'Change data';

$_['err_missing_customer_info'] = 'Please, fill in the required fields in shipping calculation form!';