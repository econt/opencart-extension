<?php

// Heading
$_['heading_title'] = 'Guaranteed by Econt';
$_['heading_title_2'] = 'Guaranteed by Econt with Cash on Delivery (GECD)';

// Text
//$_['text_home'] = '';

// Entry
//$_['entry_total'] = '';

// Help
//$_['help_text'] = '';

// Button
$_['button_confirm'] = 'Confirm Order';
$_['button_confirm_loading'] = 'Loading...';

// Success
//$_['success_save'] = 'Success: XXX!';

// Error
$_['error_payment_generation_error'] = 'Warning: Payment generation error!';
$_['error_payment_error'] = 'Payment error';