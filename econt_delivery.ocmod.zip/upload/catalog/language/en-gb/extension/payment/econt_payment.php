<?php
// Text
$_['text_title'] = 'Pay With Econt';
$_['heading_title'] = 'Guaranteed By Econt with Cash On Delivery';
$_['status_message_error'] = 'Payment Error';
$_['status_message_success'] = 'Amount is blocked';
$_['button_text_success'] = 'Back To Store';
$_['button_text_error'] = 'Try Again';
