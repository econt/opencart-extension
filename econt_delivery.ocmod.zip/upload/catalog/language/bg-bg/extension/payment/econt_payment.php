<?php

// Heading
$_['heading_title'] = 'Гарантирано от Еконт';
$_['heading_title_2'] = 'Гарантирано от Еконт с Наложен платеж (ГЕНП)';

// Text
//$_['text_home'] = '';

// Entry
//$_['entry_total'] = '';

// Help
//$_['help_text'] = '';

// Button
$_['button_confirm'] = 'Потвърди поръчката';
$_['button_confirm_loading'] = 'Зареждане...';

// Success
//$_['success_save'] = 'Success: XXX!';

// Error
$_['error_payment_generation_error'] = 'Внимание: Възникна грешка при генериране на плащане!';
$_['error_payment_error'] = 'Възникна грешка при плащане';