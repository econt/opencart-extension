<?php
// Text
$_['text_title'] = 'Pay With Econt';
$_['heading_title'] = 'Гарантирано от Еконт с наложен платеж';
$_['status_message_error'] = 'Грешка при плащане';
$_['status_message_success'] = 'Сумата е резервирана';
$_['button_text_success'] = 'Обратно към магазина';
$_['button_text_error'] = 'Опитай пак';
